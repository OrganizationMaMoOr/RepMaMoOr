﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MaMoOr_GUI
{
    /// <summary>
    /// Interaction logic for NewExercise.xaml
    /// </summary>
    public partial class NewExercise : Window
    {
        public NewExercise()
        {
            InitializeComponent();
        }

        private void btn_ne_home_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_ne_user_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_ne_uploadTask_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_ne_uploadAdditionalMaterial_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_ne_sampleSolution_Click(object sender, RoutedEventArgs e)
        {

        }

        private void item_neueAufgabe_Click(object sender, RoutedEventArgs e)
        {

        }

        private void item_eigeneAufgabe_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
