﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MaMoOr_GUI
{
    /// <summary>
    /// Interaction logic for AccountBearbeiten.xaml
    /// </summary>
    public partial class AccountBearbeiten : Window
    {
        public AccountBearbeiten()
        {
            InitializeComponent();
        }

        private void item_ea_neueAufgabe_Click(object sender, RoutedEventArgs e)
        {

        }

        private void item_ea_eigeneAufgabe_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_ea_home_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_ea_editPassword_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_ea_saveNewPassword_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_ea_cancelEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_ea_saveEdit_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
